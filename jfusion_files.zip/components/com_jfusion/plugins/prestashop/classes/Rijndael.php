<?php
/**
 * Class Rijndael
 */
class Rijndael extends RijndaelCore {

}