<?php
/**
 * Class Shop
 */
class Shop extends ShopCore
{

}