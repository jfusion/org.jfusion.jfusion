<?php

defined('_JEXEC') or die('Restricted access');

echo '<div id="jfusionframeless" '.$this->style.'>'.$this->body.'</div>';