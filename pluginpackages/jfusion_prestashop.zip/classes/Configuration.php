<?php
/**
 * Class Configuration
 */
class Configuration extends ConfigurationCore {

}