<?php
/**
 * Class Country
 */
class Country extends CountryCore {

}