<?php
/**
 * Class DbPDO
 */
class DbPDO extends DbPDOCore
{

}
